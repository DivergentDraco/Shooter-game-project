# Godot 101: Classic Shmup

![alt](http://kidscancode.org/godot_recipes/4.x/img/2d_101_screenshot.png)

Tutorial:
http://kidscancode.org/godot_recipes/4.x/games/first_2d/
